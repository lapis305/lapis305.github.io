const config = {
    localStoragePrefix: "nousagi-2001-anisong-party-rank-sorter-may25",
    title: "Nousagis 2001 Anisong Party Rank Sorter",
    description: "Nousagis party rank sorter for 2001 anisongs."
};
